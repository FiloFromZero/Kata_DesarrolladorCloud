package com.coedesarrollo.Back_Kata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackKataApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackKataApplication.class, args);
	}

}
