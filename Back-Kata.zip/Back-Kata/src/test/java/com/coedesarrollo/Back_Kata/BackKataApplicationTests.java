package com.coedesarrollo.Back_Kata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackKataApplicationTests {

	@Test
	void contextLoads() {
	}

}
